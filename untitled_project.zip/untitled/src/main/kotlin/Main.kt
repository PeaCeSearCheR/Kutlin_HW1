
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import kotlinx.coroutines.runBlocking

data class GithubUser(val login: String, val name: String?, val public_repos: Int, val followers: Int, val following: Int)

interface GithubService {
    @GET("users/{username}")
    suspend fun getUser(@Path("username") username: String): GithubUser
}

fun main() = runBlocking {
    println("Enter GitHub username:")
    val username = readLine() ?: return@runBlocking

    val retrofit = Retrofit.Builder()
        .baseUrl("https://api.github.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val service = retrofit.create(GithubService::class.java)

    try {
        val user = service.getUser(username)
        println("Username: ${user.login}")
        println("Name: ${user.name}")
        println("Public Repos: ${user.public_repos}")
        println("Followers: ${user.followers}")
        println("Following: ${user.following}")
    } catch (e: Exception) {
        println("Error fetching user data: ${e.message}")
    }
}
